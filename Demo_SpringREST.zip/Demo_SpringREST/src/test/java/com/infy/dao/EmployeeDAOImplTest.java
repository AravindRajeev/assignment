package com.infy.dao;





import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.infy.model.Employee;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmployeeDAOImplTest {
	@Mock 
	private EmployeeDAO employeeDao;
	@Test
	 public void addEmployeeTestValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.addEmployee(employee)).thenReturn(employee.getEmployeeId());
		Integer empId=employeeDao.addEmployee(employee);
		Assert.assertEquals(new Integer(1067600), empId);
		
	}
	@Test
	 public void updateEmployeeTestValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.updateEmployee(employee)).thenReturn(employee.getEmployeeId());
		Integer empId=employeeDao.updateEmployee(employee);
		Assert.assertEquals(new Integer(1067600), empId);
		
	}
	@Test
	 public void deleteEmployeeTestValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.deleteEmployee(employee.getEmployeeId())).thenReturn(employee.getEmployeeId());
		Integer empId=employeeDao.deleteEmployee(employee.getEmployeeId());
		Assert.assertEquals(new Integer(1067600), empId);
		
	}
	@Test
	 public void updateEmployeeTestInValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.updateEmployee(employee)).thenReturn(-1);
		Integer empId=employeeDao.updateEmployee(employee);
		Assert.assertEquals(new Integer(-1), empId);
		
	}
	@Test
	 public void deleteEmployeeTestInValid() throws Exception{
		Employee employee =new Employee();
		employee.setEmailId("john.david@infosys.com");
		employee.setEmployeeId(1067600);
		employee.setEmployeeName("John David");
		employee.setUnit("RCLADM");
		when(employeeDao.deleteEmployee(employee.getEmployeeId())).thenReturn(-1);
		Integer empId=employeeDao.deleteEmployee(employee.getEmployeeId());
		Assert.assertEquals(new Integer(-1), empId);
		
	}
}
