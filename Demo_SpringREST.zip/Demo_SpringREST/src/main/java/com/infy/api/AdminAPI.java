package com.infy.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.infy.model.Admin;
import com.infy.model.Employee;
import com.infy.service.AdminService;


@CrossOrigin
@RestController
@RequestMapping(value="/infy")
public class AdminAPI {
	
	@Autowired
	private AdminService adminService;
	
	@GetMapping(value = "/getAdmin/{username}")
	public ResponseEntity<Admin> getEmployeeDetails(@PathVariable String username)  throws Exception  {
		try {
			Admin admin = adminService.getAdminData(username);
			ResponseEntity<Admin> response = new ResponseEntity<Admin>(admin, HttpStatus.OK);
			return response;
		}
		catch(ResponseStatusException exception) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Error");
		}
		
	}
	
	
    @PostMapping(value = "/addAdmin")
	public ResponseEntity<String> addEmployee(@RequestBody Admin admin) throws Exception  {
		adminService.addAdminData(admin);
		String successMessage = "Admin added successfully";
		ResponseEntity<String> response = new ResponseEntity<String>(successMessage, HttpStatus.CREATED);
		return response;
	}
}
