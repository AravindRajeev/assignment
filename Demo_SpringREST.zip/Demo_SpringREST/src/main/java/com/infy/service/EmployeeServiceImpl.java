package com.infy.service;

import java.util.List;

import javax.transaction.Transactional;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dao.EmployeeDAO;
import com.infy.model.Employee;

@Service(value = "employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;

	public Employee getEmployee(Integer employeeId) throws Exception {

		Employee employee = employeeDAO.getEmployee(employeeId);
		if (employee == null) {
			throw new Exception("Service.EMPLOYEE_UNAVAILABLE");
		}
		return employee;
	}

	@Override
	public Integer addEmployee(Employee employee) throws Exception {
		// TODO Auto-generated method stub
		if (employeeDAO.getEmployee(employee.getEmployeeId()) != null) {
			throw new Exception("Service.EMPLOYEE_ALREADY_EXISTS");
		}
		
		return employeeDAO.addEmployee(employee);
	}

	public Integer updateEmployee(Employee employeeParam) throws Exception {
		Employee employee = employeeDAO.getEmployee(employeeParam.getEmployeeId());
		if (employee == null) {
			throw new Exception("Service.EMPLOYEE_UNAVAILABLE");
		}		
		return employeeDAO.updateEmployee(employeeParam);
	}

	public Integer deleteEmployee(Integer employeeId) throws Exception {
		Employee employee = employeeDAO.getEmployee(employeeId);
		if (employee == null) {
			throw new Exception("Service.EMPLOYEE_UNAVAILABLE");
		}
		return employeeDAO.deleteEmployee(employeeId);
	}

	public List<Employee> getAllEmployeeDetails() throws Exception {
		List<Employee> employeeList = employeeDAO.getAllEmployeeDetails();
		if (employeeList == null) {
			throw new Exception("Service.NO_EMPLOYEE_AVAILABLE");
		}
		return employeeList;
	}
}
