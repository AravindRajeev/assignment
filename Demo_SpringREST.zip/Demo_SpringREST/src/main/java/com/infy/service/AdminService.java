package com.infy.service;

import com.infy.model.Admin;

public interface AdminService {
	public String addAdminData(Admin admin) throws Exception;
	public Admin getAdminData(String username) throws Exception;
}
