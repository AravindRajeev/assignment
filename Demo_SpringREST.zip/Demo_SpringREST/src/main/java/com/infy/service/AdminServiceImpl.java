package com.infy.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.AdminDAO;
import com.infy.model.Admin;




@Service(value = "adminService")
@Transactional
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	private AdminDAO adminDAO;

	@Override
	public String addAdminData(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		if (adminDAO.getAdminData(admin.getUsername()) != null) {
			throw new Exception("Service.ADMIN_ALREADY_EXISTS");
		}
		
		return adminDAO.addAdminData(admin);
	}

	@Override
	public Admin getAdminData(String username) throws Exception {
		// TODO Auto-generated method stub
		Admin admin = adminDAO.getAdminData(username);
		if (admin == null) {
			throw new Exception("Service.ADMIN_UNAVAILABLE");
		}
		return admin;
	}

}
