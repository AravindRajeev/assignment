package com.infy.dao;

import com.infy.model.Admin;

public interface AdminDAO {
	public String addAdminData(Admin admin) throws Exception;
	public Admin getAdminData(String username) throws Exception;
}
