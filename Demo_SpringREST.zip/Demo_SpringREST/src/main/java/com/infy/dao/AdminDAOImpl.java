package com.infy.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.infy.entity.AdminEntity;
import com.infy.model.Admin;

@Repository(value = "adminDAO")
public class AdminDAOImpl implements AdminDAO {
	
	@PersistenceContext
	private EntityManager entity;

	@Override
	public String addAdminData(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		AdminEntity adminEntity=new AdminEntity();
		adminEntity.setUsername(admin.getUsername());
		adminEntity.setPassword(admin.getPassword());
		entity.persist(adminEntity);
		return adminEntity.getUsername();
	}

	@Override
	public Admin getAdminData(String username) throws Exception {
		// TODO Auto-generated method stub
		Admin admin=new Admin();
		AdminEntity adminEntity=entity.find(AdminEntity.class, username);
		if(adminEntity!=null) {
			admin.setPassword(adminEntity.getPassword());
			admin.setUsername(adminEntity.getUsername());
			return admin;
		}
		return null;
	}
	
	
}
