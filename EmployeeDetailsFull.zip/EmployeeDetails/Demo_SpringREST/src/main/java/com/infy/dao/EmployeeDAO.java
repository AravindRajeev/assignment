package com.infy.dao;

import java.util.List;

//import java.util.List;


import com.infy.model.Employee;

public interface EmployeeDAO {
	public Integer addEmployee(Employee employee) throws Exception;
	public Employee getEmployee(Integer employeeId) throws Exception;
	public Integer updateEmployee(Employee employee) throws Exception;
	public Integer deleteEmployee(Integer employeeId) throws Exception;
	public List<Employee> getAllEmployeeDetails();
}
