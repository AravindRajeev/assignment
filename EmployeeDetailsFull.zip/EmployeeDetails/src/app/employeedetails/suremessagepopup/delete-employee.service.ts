import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Employee } from '../Employee';
import { Observable } from '../../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class DeleteEmployeeService {
  url:string;
  constructor(private http:HttpClient) { }
  deleteEmployee(employeeId:Number):Observable<String>{
    console.log(employeeId)
    this.url="http://localhost:3557/infy/deleteEmployee/"+employeeId;
    return this.http.delete<String>(this.url);

  }
 
}
