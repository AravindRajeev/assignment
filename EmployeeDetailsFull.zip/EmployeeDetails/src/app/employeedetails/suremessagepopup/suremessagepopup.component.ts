import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '../../../../node_modules/@angular/material/dialog';
import { DeleteEmployeeService } from './delete-employee.service';
import { UpdaterendererComponent } from '../updaterenderer/updaterenderer.component';
import { DeleterendererComponent } from '../deleterenderer/deleterenderer.component';


@Component({
  selector: 'app-suremessagepopup',
  templateUrl: './suremessagepopup.component.html',
  styleUrls: ['./suremessagepopup.component.css']
})
export class SuremessagepopupComponent implements OnInit {
  message:String;
  error:String;
  messagePass=this.data.employeeId
  
 
  constructor(@Inject(MAT_DIALOG_DATA) public data:any,private deleteEmployeeService:DeleteEmployeeService,public dialog: MatDialog) { }

  ngOnInit() {
  }
  onNoClick():void{
    const dialogRef=this.dialog.closeAll();
  }
  
   
  
  deleteEmployee(){
    this.deleteEmployeeService.deleteEmployee(this.data.employeeId).subscribe(
      response=>this.message=response,
      error=>this.error=error
    )   
    // this.closeSure();
  }
}
