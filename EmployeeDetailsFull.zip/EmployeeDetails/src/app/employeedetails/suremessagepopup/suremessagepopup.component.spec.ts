import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuremessagepopupComponent } from './suremessagepopup.component';

describe('SuremessagepopupComponent', () => {
  let component: SuremessagepopupComponent;
  let fixture: ComponentFixture<SuremessagepopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuremessagepopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuremessagepopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
