import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { MatDialog } from '../../../../node_modules/@angular/material/dialog';
import { EmployeedetailspopupComponent } from '../employeedetailspopup/employeedetailspopup.component';

@Component({
  selector: 'app-updaterenderer',
  templateUrl: './updaterenderer.component.html',
  styleUrls: ['./updaterenderer.component.css']
})
export class UpdaterendererComponent implements OnInit {
  data:String;
  params:any;
  employee:Employee=new Employee();
  message:String;
  error:String;
  modalvalue:boolean=false;
  constructor(public dialog: MatDialog) { }

  openDialog(): void {
    const dialogRef = this.dialog.open(EmployeedetailspopupComponent, {
      width: '500px',height:'400px',
      data: {employeeId: this.params.data.employeeId,employeeName:this.params.data.employeeName,emailId:this.params.data.emailId,unit:this.params.data.unit}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      
    });
  }
  actionEvent($event){
    if (this.params.onClick instanceof Function) {
      const params = {
        event: $event,
        rowData: this.params.node.data
      }
      this.params.onClick(params);
    }
  }
  agInit(params){
    this.params=params;
    this.data=params.value;
    
  }
  ngOnInit() {
  }

}
