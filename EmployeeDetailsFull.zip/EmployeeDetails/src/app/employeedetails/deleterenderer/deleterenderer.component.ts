import { Component, OnInit, Output,EventEmitter } from '@angular/core';
import { MatDialog } from '../../../../node_modules/@angular/material/dialog';
import { SuremessagepopupComponent } from '../suremessagepopup/suremessagepopup.component';

@Component({
  selector: 'app-deleterenderer',
  templateUrl: './deleterenderer.component.html',
  styleUrls: ['./deleterenderer.component.css']
})
export class DeleterendererComponent implements OnInit {
  params:any;
  data:string;
  @Output() deleteClicked: EventEmitter<any> = new EventEmitter();
  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }
  onDeleteClick($event) {
    if (this.params.onClick instanceof Function) {
      const params = {
        event: $event,
        rowData: this.params.node.data
      }
      this.params.onClick(params);
    }
  }
  
  agInit(params){
    this.params=params;
    this.data=params.value;
    
  }
}
