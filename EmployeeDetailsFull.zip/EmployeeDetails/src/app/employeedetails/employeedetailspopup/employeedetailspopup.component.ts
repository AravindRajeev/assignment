import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '../../../../node_modules/@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '../../../../node_modules/@angular/material/dialog';
import { Employee } from '../Employee';
import { SuccessrendererComponent } from './successrenderer/successrenderer.component';

@Component({
  selector: 'app-employeedetailspopup',
  templateUrl: './employeedetailspopup.component.html',
  styleUrls: ['./employeedetailspopup.component.css']
})
export class EmployeedetailspopupComponent implements OnInit {
  message:String;
  error:String;
  employeeForm: FormGroup;
  employee:Employee=new Employee();
  empId:string;
  empName:string;
  emaId:string;
  un:string;
  res:any
  gEmployee:Employee=new Employee();
  method:string;
  value:string;
  constructor(private formBuilder:FormBuilder, public dialogRef:MatDialogRef<EmployeedetailspopupComponent>,
  @Inject(MAT_DIALOG_DATA) public data:any,public dialog: MatDialog) {
      
   }

  ngOnInit() {
    
    if(this.data==null){
      this.empId='';
      this.empName='';
      this.emaId='';
      this.un='';
    }
    else{
      this.empId=this.data.rowData.employeeId;
      this.empName=this.data.rowData.employeeName;
      this.emaId=this.data.rowData.emailId
      this.un=this.data.rowData.unit
    }
    this.employeeForm=this.formBuilder.group({
      employeeId:[this.empId,Validators.required],
      employeeName:[this.empName,Validators.required],
      emailId:[this.emaId,Validators.required],
      unit:[this.un,Validators.required]
    })
  }
 
  closeDialog():void{
    const dialogRef=this.dialog.closeAll();
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(SuccessrendererComponent, {
      width: '300px',height:'150px',
      data: {value:this.method}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      
    });
  }

    
    
    submit() {
      this.dialogRef.close(this.employeeForm.value);
    }

    close() {
        this.dialogRef.close();
    }

    
    
  }


