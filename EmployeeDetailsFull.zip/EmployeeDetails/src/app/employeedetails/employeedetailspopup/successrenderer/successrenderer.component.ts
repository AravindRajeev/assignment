import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '../../../../../node_modules/@angular/material/dialog';

@Component({
  selector: 'app-successrenderer',
  templateUrl: './successrenderer.component.html',
  styleUrls: ['./successrenderer.component.css']
})
export class SuccessrendererComponent implements OnInit {
  message:string=this.data.value;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data:any,public dialog: MatDialog) { }
   
  ngOnInit() {
  }
  closeDialog():void{
    const dialogRef=this.dialog.closeAll();
  }

}
