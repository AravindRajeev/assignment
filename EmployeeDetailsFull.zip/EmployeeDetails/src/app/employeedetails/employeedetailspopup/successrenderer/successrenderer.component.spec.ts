import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessrendererComponent } from './successrenderer.component';

describe('SuccessrendererComponent', () => {
  let component: SuccessrendererComponent;
  let fixture: ComponentFixture<SuccessrendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuccessrendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuccessrendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
