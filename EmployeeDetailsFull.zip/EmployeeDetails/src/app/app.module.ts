import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';
import { UpdaterendererComponent } from './employeedetails/updaterenderer/updaterenderer.component';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { EmployeedetailspopupComponent } from './employeedetails/employeedetailspopup/employeedetailspopup.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DeleterendererComponent } from './employeedetails/deleterenderer/deleterenderer.component';
import { SuremessagepopupComponent } from './employeedetails/suremessagepopup/suremessagepopup.component';
import { SuccessrendererComponent } from './employeedetails/employeedetailspopup/successrenderer/successrenderer.component';
import { MatFormFieldModule, MatInputModule } from '@angular/material';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    EmployeedetailsComponent,
    UpdaterendererComponent,
    EmployeedetailspopupComponent,
    DeleterendererComponent,
    SuremessagepopupComponent,
    SuccessrendererComponent
    
    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AgGridModule.withComponents([AppComponent]),
    HttpClientModule,
    ReactiveFormsModule,
    MatDialogModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule
    
    
  ],
  providers: [ { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} }],entryComponents:[UpdaterendererComponent,EmployeedetailspopupComponent,DeleterendererComponent,SuremessagepopupComponent,SuccessrendererComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
