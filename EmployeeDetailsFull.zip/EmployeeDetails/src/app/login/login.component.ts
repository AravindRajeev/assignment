// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;
  username:String;
  password:String;
  success:String='no';
  constructor(private formBuilder:FormBuilder) { }
  public login(){
    this.username=this.loginForm.controls.username.value;
    this.password=this.loginForm.controls.password.value;
    if(this.username=='admin' && this.password=='password'){
      this.success='yes';
    }
    else{
      this.success='no';
    }
  }
  ngOnInit() {
    this.loginForm=this.formBuilder.group({
      username:['',Validators.required],
      password:['',Validators.required]
    })
  }

}
