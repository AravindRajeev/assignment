import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from './login.service';
import { Admin } from './Admin';
import { MatSnackBar } from '../../../node_modules/@angular/material';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  signUpForm: FormGroup;
  username: String;
  password: String;
  errorMessage: String = "Incorrect username or password";
  success: String = 'no';
  errorCond: boolean;
  admin: Admin = new Admin();
  error: string;
  isSignUp: string;
  isLogin: string = "yes";
  successMessage:String
  constructor(private formBuilder: FormBuilder, private loginService: LoginService,private snackBar: MatSnackBar) { }

  public login() {
    if (this.username == this.admin.username && this.password == this.admin.password) {
      this.success = 'yes';
      this.isLogin = "no"
      this.isSignUp="no"
      this.errorCond = false;
    }
    else{
      console.log(this.error)
      this.success = 'no';
      this.isLogin = "yes"
      this.isSignUp="no"
      this.errorCond = true;

    }
  }
  public getAdminData() {
    this.username = this.loginForm.controls.username.value;
    this.password = this.loginForm.controls.password.value;
    this.loginService.getAdminData(this.username).subscribe(
      response => { this.admin = response; this.login() },
      error => {this.error = error;this.login()}
    )


  }
  doSignUp() {
    this.isSignUp = "yes"
    this.isLogin = "no"
  }
  signUp(){
    this.username = this.signUpForm.controls.username.value;
    this.password = this.signUpForm.controls.password.value;
    this.admin.username=this.username;
    this.admin.password=this.password
    this.loginService.addAdminData(this.admin).subscribe(
      response=>this.successMessage=response,
      error=>this.errorMessage=error
    )
    this.openSnackBar("Admin added successfully", "Close")
    window.location.reload();
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 3000,
    });
  }

  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    })

    this.signUpForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    })
  }

}
