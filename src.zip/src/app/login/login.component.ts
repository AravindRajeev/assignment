import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;
  username:String;
  password:String;
  errorMessage:String="Incorrect username or password";
  success:String='no';
  errorCond:boolean;
  constructor(private formBuilder:FormBuilder) { }
  public login(){
    this.username=this.loginForm.controls.username.value;
    this.password=this.loginForm.controls.password.value;
    if(this.username=='admin' && this.password=='password'){
      this.success='yes';
      this.errorCond=false;
    }
    else{
      this.success='no';
      this.errorCond=true;
      console.log(this.errorCond)

    }
  }
  ngOnInit() {
    this.loginForm=this.formBuilder.group({
      username:['',Validators.required],
      password:['',Validators.required]
    })
  }

}
