export class Admin{
    username: String;
    password: String;

    public getUsername() {
        return this.username
    }
    public setUsername(username:String){
        this.username=username;
    }
    public getPassword() {
        return this.password
    }
    public setPassword(password:String){
        this.password=password;
    }
}