import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './Admin';
import { HttpClient } from '../../../node_modules/@angular/common/http';





@Injectable({
  providedIn: 'root'
})
export class LoginService {
  url:string;
  constructor(private http:HttpClient) { }
  getAdminData(username:String):Observable<Admin>{
    this.url='http://localhost:3557/infy/getAdmin/'+username;
    return this.http.get<Admin>(this.url);
  }
  addAdminData(admin:Admin):Observable<String>{
    this.url='http://localhost:3557/infy/addAdmin';
    return this.http.post<String>(this.url,admin);
  }
}
