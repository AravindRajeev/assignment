export class Employee {
    employeeId: Number;
    employeeName: String;
    emailId: String;
    unit: String;
    dob: Date;
    gender: String;

    public getDob() {
        return this.dob
    }
    public setDob(dob:Date){
        this.dob=dob;
    }
    public getGender(){
        return this.gender
    }
    public setGender(gender:String){
        this.gender=gender
    }
    public getEmployeeId(): Number {
        return this.employeeId;
    }
    public setEmployeeId(employeeId: Number) {
        this.employeeId = employeeId;
    }

    public getEmployeeName(): String {
        return this.employeeName;
    }

    public setEmployeeName(employeeName: String) {
        this.employeeName = employeeName;
    }

    public getEmailId(): String {
        return this.emailId;
    }

    public setEmailId(emailId: String) {
        this.emailId = emailId;
    }


    public getUnit(): String {
        return this.unit;
    }

    public setUnit(unit: String) {
        this.unit = unit;
    }
}