import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './Employee';
import {HttpClient} from '@angular/common/http'


@Injectable({
  providedIn: 'root'
})
export class EmployeedetailsService {
  url:string;
  getEmployee():Observable<Employee[]>{
    this.url='http://localhost:3557/infy/employees';
    return this.http.get<Employee[]>(this.url);
  }
  
  deleteEmployee(employeeId:Number):Observable<String>{
    console.log(employeeId)
    this.url="http://localhost:3557/infy/deleteEmployee/"+employeeId;
    return this.http.delete<String>(this.url);

  }
  addEmployee(employee:Employee):Observable<String>{
    console.log(employee)
    this.url="http://localhost:3557/infy/addEmployee";
    return this.http.post<String>(this.url,employee);
  }
  updateEmployee(employee:Employee):Observable<String>{
    console.log(employee.getEmployeeName())
    this.url="http://localhost:3557/infy/updateEmployee";
    return this.http.post<String>(this.url,employee);
  }
  constructor(private http:HttpClient) { }
}
