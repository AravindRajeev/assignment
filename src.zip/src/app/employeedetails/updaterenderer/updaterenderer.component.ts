import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { MatDialog } from '../../../../node_modules/@angular/material/dialog';
import { EmployeedetailspopupComponent } from '../employeedetailspopup/employeedetailspopup.component';

@Component({
  selector: 'app-updaterenderer',
  templateUrl: './updaterenderer.component.html',
  styleUrls: ['./updaterenderer.component.css']
})
export class UpdaterendererComponent implements OnInit {
  data:String;
  params:any;
  employee:Employee=new Employee();
  message:String;
  error:String;
  modalvalue:boolean=false;
  constructor(public dialog: MatDialog) { }

  
  actionEvent($event){
    if (this.params.onClick instanceof Function) {
      const params = {
        event: $event,
        rowData: this.params.node.data,
        action:"update"
      }
      this.params.onClick(params);
    }
  }
  onDeleteClick($event) {
    if (this.params.onClick instanceof Function) {
      const params = {
        event: $event,
        rowData: this.params.node.data,
        action:"delete"
      }
      this.params.onClick(params);
    }
  }
  agInit(params){
    this.params=params;
    this.data=params.value;
    
  }
  ngOnInit() {
  }

}
