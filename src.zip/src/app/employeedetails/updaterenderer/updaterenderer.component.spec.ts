import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdaterendererComponent } from './updaterenderer.component';

describe('UpdaterendererComponent', () => {
  let component: UpdaterendererComponent;
  let fixture: ComponentFixture<UpdaterendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdaterendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdaterendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
