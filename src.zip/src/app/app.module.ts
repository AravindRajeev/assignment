import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';
import { UpdaterendererComponent } from './employeedetails/updaterenderer/updaterenderer.component';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { EmployeedetailspopupComponent } from './employeedetails/employeedetailspopup/employeedetailspopup.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatFormFieldModule, MatInputModule, MatSnackBarModule, MatDatepickerModule, MatNativeDateModule, MatRadioModule, MAT_DATE_LOCALE } from '@angular/material';
import { MessagepopupComponent } from './messagepopup/messagepopup.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    EmployeedetailsComponent,
    UpdaterendererComponent,
    EmployeedetailspopupComponent,
    MessagepopupComponent,

    
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AgGridModule.withComponents([AppComponent]),
    HttpClientModule,
    ReactiveFormsModule,
    MatDialogModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
    MatDatepickerModule, 
    MatNativeDateModule,
    MatRadioModule
   
    
    
  ],
  providers: [ { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} },{provide: MAT_DATE_LOCALE, useValue: 'en-US'},MatDatepickerModule,MatRadioModule],entryComponents:[UpdaterendererComponent,EmployeedetailspopupComponent,MessagepopupComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
